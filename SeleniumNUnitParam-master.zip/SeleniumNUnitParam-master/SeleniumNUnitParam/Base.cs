﻿using OpenQA.Selenium;

namespace SeleniumNUnitParam
{

    //Base class
    public class Base
    {

        public IWebDriver Driver { get; set; }

    }
}
